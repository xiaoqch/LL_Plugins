#pragma once

template <typename T>
struct InvertableFilter {
    T    value;
    bool inverted;
};