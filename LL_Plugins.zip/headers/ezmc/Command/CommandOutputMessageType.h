#pragma once

enum class CommandOutputMessageType {};