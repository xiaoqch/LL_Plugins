#include "pch.h"
#include "loader/Loader.h"
#include "SymHelper.h"
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include "seh_exception.hpp"
#include "JsonHelper.h"

std::map<long long, long long> agentMap;
long long ticks;
std::map<long long, std::function<void()>> funcSchedule;
void setTimeOut(std::function<void()> func, long long denyTick) {
	auto scheduleTick = ticks + denyTick;
	while (funcSchedule.size() > 0 && funcSchedule.find(scheduleTick) != funcSchedule.end())
	{
		++scheduleTick;
	}
	funcSchedule[scheduleTick] = func;
}

bool hasMaster(Actor* actor) {
	return agentMap.size() > 0 && agentMap.end() != agentMap.find(actor->getUniqueID().id);
}
ActorUniqueID getMasterUID(Actor* agent) {
	ActorUniqueID agentUID = agent->getUniqueID();
	return ActorUniqueID(agentMap[agentUID.id]);
}
Player* getMaster(Player* agent) {
	return getPlayerByAUID(getMasterUID(agent));
}
Mob* getMaster(Mob* agent) {
	return getMobByAUID(getMasterUID(agent));
}
Actor* getMaster(Actor* agent) {
	return getActorByAUID(getMasterUID(agent));
}
template<typename T>
T getMasterOrNull(T agent) {
	if (!hasMaster(agent)) {
		return nullptr;
	}
	T master = getMaster(agent);
	if (master == nullptr) {
		agentMap.erase(agent->getUniqueID().id);
		if (isPlayer(agent)) {
			// 防止忘记清除？
			sendPlayerText((Player*)agent, "获取被代理实体失败，清除代理");
		}
	}
	return master;
}


std::string getActorDescription(Actor* actor) {
	if (actor == nullptr) {
		std::cerr << "getActorDescription 传入空指针" << std::endl;
		return "";
	}
	auto auid = std::to_string(actor->getUniqueID().id);
	return getActorName(actor) + "(" + auid + ")";
}

enum class AGENT_SET : int { set = 1 };
bool oncmd_agentSet(CommandOrigin const& ori, CommandOutput& outp, MyEnum<AGENT_SET>& op, CommandSelector<Actor>& masterSel, optional<CommandSelector<Actor>>& agentSel) {
	Actor* master;
	Actor* agent;
	auto masterRes = masterSel.results(ori);
	if (masterRes.count() != 1) {
		outp.addMessage("[Operation Agent] 只能设置一个被代理实体");
		return false;
	}
	master = *masterRes.begin();
	if (agentSel.set) {
		auto agentRes = agentSel.val().results(ori);
		if (agentRes.count() != 1) {
			outp.addMessage("[Operation Agent] 只能设置一个代理实体");
			return false;
		}
		agent = *agentRes.begin();
	}
	else {
		agent = ori.getEntity();
		if (agent == nullptr) {
			outp.addMessage("[Operation Agent] 控制台执行时必须设置代理实体");
			return false;
		}
	}
	agentMap[agent->getUniqueID().id] = master->getUniqueID().id;
	outp.addMessage("[Operation Agent] 代理设置成功");
	outp.addMessage(getActorDescription(agent) + " -> " + getActorDescription(master));
	return true;
}

enum class AGENT_CLEAR : int { clear = 1 };
bool oncmd_agentClear(CommandOrigin const& ori, CommandOutput& outp,
	MyEnum<AGENT_CLEAR>& op,
	optional<CommandSelector<Actor>>& agent) {
	int count = 0;
	if (agent.set) {
		auto res = agent.val().results(ori);
		for (auto actor = res.begin(); actor != res.end(); ++actor) {
			auto k = agentMap.find((*actor)->getUniqueID().id);
			if (k != agentMap.end()) {
				agentMap.erase(k);
				count++;
			}
		}
		switch (count) {
		case 0:
			outp.addMessage("[Operation Agent] 没有需要清除的代理设置");
			return false;
		case 1:
			outp.addMessage("[Operation Agent] 清除了 " + (*res.begin())->getNameTag() + " 的代理");
			return true;
		default:
			outp.addMessage("[Operation Agent] 清除了 " + std::to_string(count) + " 个代理");
			return true;
		}
	}
	else {
		Actor* entity = ori.getEntity();
		if (entity != nullptr) {
			auto k = agentMap.find(entity->getUniqueID().id);
			if (k != agentMap.end()) {
				agentMap.erase(k);
				outp.addMessage("[Operation Agent] 清除代理成功");
			}
			else {
				outp.addMessage("[Operation Agent] 没有代理");
			}
		}
		else {
			outp.addMessage(
				"[Operation Agent] 控制台执行时必须选择需要清除的代理");
			return false;
		}
	}
	return true;
}

enum class AGENT_OTHERS : int {
	list = 1,
	clearall = 2,
};
bool oncmd_agentOthers(CommandOrigin const& ori, CommandOutput& outp, MyEnum<AGENT_OTHERS>& op) {
	switch (op.val)
	{
	case AGENT_OTHERS::list:
		outp.addMessage("代理列表(Agent->Master):  ");
		for (auto it = agentMap.begin(); it != agentMap.end(); ++it) {
			auto agent = getActorByAUID((*it).first);
			auto master = getActorByAUID((*it).second);
			if (agent == nullptr || master == nullptr) {
				agentMap.erase((*it).first);
			}
			else {
				std::string strAgent = getActorDescription(agent);
				std::string strMaster = getActorDescription(master);
				outp.addMessage(strAgent + " -> " + strMaster);
			}
		}
		break;
	case AGENT_OTHERS::clearall:
		size_t count = agentMap.size();
		agentMap.clear();
		if (count > 0) {
			outp.addMessage("已清除所有代理设置，共 " + std::to_string(count) + " 个");
			return true;
		}
		else {
			outp.addMessage("当前没有已设置代理");
			return false;
		}
	}
	return false;
}
void regListener() {
	Event::addEventListener([](RegCmdEV ev) {
		CMDREG::SetCommandRegistry(ev.CMDRg);
		MakeCommand("opagent", "代理实体执行某些操作", 1);  //注册指令
		CEnum<AGENT_SET> _1("set", { "set" });
		CEnum<AGENT_CLEAR> _2("clear", { "clear" });
		CEnum<AGENT_OTHERS> _3("op", { "list", "clearall" });
		CmdOverload(opagent, oncmd_agentSet, "set", "master", "agent");  //重载指令
		CmdOverload(opagent, oncmd_agentClear, "clear", "agent");  //重载指令
		CmdOverload(opagent, oncmd_agentOthers, "op");  //重载指令
		});
	Event::addEventListener([](JoinEV ev) {
		Player* player = ev.Player;
		if (player == nullptr) {
			return;
		}
		long long auid = player->getUniqueID().id;
		if (getDataType(auid) == DataType::Ride) {
			setTimeOut([auid]() {
				Player* player = getPlayerByAUID(auid);
				if (player == nullptr) {
					return;
				}
				long long  mountsUID = getRideData(auid);
				Actor* mounts = getActorByAUID(mountsUID);
				if (mounts != nullptr) {
					player->startRiding(*mounts);
					std::cout << "玩家" << getActorDescription(player) << "上线自动骑乘" << std::endl;
				}
				else {
					std::cout << "没找到骑乘目标，清除玩家" << getActorDescription(player) << "自动骑乘数据" << std::endl;
					deleteData(std::to_string(auid));
				}
				}, 100);
		}
		});
}

void entry() {
	regListener();
	std::cout << "[Operation Agent] 操作代理已加载." << std::endl;
}

// ===== onSpawnProjectile =====
//THook(Actor*, "?spawnProjectile@Spawner@@QEAAPEAVActor@@AEAVBlockSource@@AEBUActorDefinitionIdentifier@@PEAV2@AEBVVec3@@3@Z",
//	void* _this, BlockSource* bs, ActorDefinitionIdentifier* adi, Actor* spawner, Vec3* pos, Vec3* direct) {
//	auto master = getMasterOrNull(spawner);
//	if (master!=nullptr) {
//		if (isPlayer(master)) {
//			sendPlayerText((Player*)spawner, "代理" + getActorDescription(master) + "投掷");
//		}
//		Vec3 mpos = master->getPos();
//		return original(_this, bs, adi, master, &mpos, direct);
//	}
//	return original(_this, bs, adi, spawner, pos, direct);
//}
THook(Actor*, "?spawnProjectile@Spawner@@QEAAPEAVActor@@AEAVBlockSource@@AEBUActorDefinitionIdentifier@@PEAV2@AEBVVec3@@3@Z",
	void* _this, BlockSource* bs, ActorDefinitionIdentifier* adi, Actor* spawner,
	Vec3* pos, Vec3* direct) {
	Actor* proj = original(_this, bs, adi, spawner, pos, direct);
	if (proj == nullptr) {
		return proj;
	}
	if (spawner != nullptr && hasMaster(spawner)) {
		auto masterUID = agentMap[spawner->getUniqueID().id];
		ActorUniqueID projUID = proj->getUniqueID();
		setTimeOut([projUID, masterUID]() {
			Actor* tempProj = getActorByAUID(projUID);
			if (tempProj != nullptr) {
				setOwner(tempProj, masterUID);
			}
			}, 0);
		if (spawner != nullptr && isPlayer(spawner)) {
			auto master = getActorByAUID(masterUID);
			if (master != nullptr) {
				sendPlayerText((Player*)spawner, "代理" + getActorDescription(master) + "投掷成功");
			}
			else {
				agentMap.erase(spawner->getUniqueID().id);
				// 防止忘记清除？
				sendPlayerText((Player*)spawner, "获取被代理实体失败，清除该代理");
			}
		}
	}
	return proj;
}

// ===== addRider =====
THook(bool, "?startRiding@Mob@@UEAA_NAEAVActor@@@Z", Mob* _this, Actor* actor) {
	auto master = getMasterOrNull(_this);
	if (master != nullptr) {
		if (isPlayer(_this)) {
			sendPlayerText((Player*)_this, "代理" + getActorDescription(master) + "骑乘成功");
		}
		if (isPlayer(master)) {
			WPlayer(*(Player*)master).teleport(actor->getPos(), actor->getDimensionId());
		}
		else {
			// 无效？？？
			WActor(*master).teleport(actor->getPos(), actor->getDimensionId());
		}
		if (isPlayer(master)) {
			setRideData(master->getUniqueID().id, actor->getUniqueID().id, getActorName(master) + "->" + getActorName(actor));
		}
		return original(master, actor);
	}
	return original(_this, actor);
}

// ===== startSleepInBed =====
THook(bool, "?startSleepInBed@Player@@UEAA?AW4BedSleepingResult@@AEBVBlockPos@@@Z",
	Player* player, BlockPos* bpos) {
	auto master = getMasterOrNull(player);
	if (master != nullptr) {
		// 传送以防止假人掉到底下方块里，假人客户端的问题
		Vec3 aboveBed = { bpos->x + 0.5f, bpos->y + 2.0f, bpos->z + 0.5f };
		WPlayer(*(Player*)master).teleport(aboveBed, player->getDimensionId());
		auto rtn = original(master, bpos);
		if (isSleeping(master)) {
			sendPlayerText((Player*)player, "代理" + getActorDescription(master) + "睡觉成功，并设置自动睡觉");
		}
		else {
			sendPlayerText((Player*)player, "代理" + getActorDescription(master) + "睡觉失败，但已设置自动睡觉");
		}
		setSleepData(master->getUniqueID().id, *bpos, getActorName(master) + " -> (" + bpos->toString() + ")");
		return rtn;
	}
	auto rtn = original(player, bpos);
	if (!isSleeping(player)) {
		return rtn;
	}
	auto players = liteloader::getAllPlayers();
	for (auto playerIter = players.begin(); playerIter != players.end(); ++playerIter) {
		if (!isSleeping(*playerIter)) {
			long long puid = (*playerIter)->getUniqueID().id;
			if (getDataType(puid) == DataType::Sleep) {
				BlockPos pbpos = getSleepData(puid);
				// 传送以防止假人掉到底下方块里，假人客户端的问题
				Vec3 aboveBed = { pbpos.x + 0.5f, pbpos.y + 2.0f, pbpos.z + 0.5f };
				WPlayer(*(Player*)*playerIter).teleport(aboveBed, player->getDimensionId());
				original(*playerIter, &pbpos);
				if (!isSleeping(*playerIter)) {
					deleteData(std::to_string((*playerIter)->getUniqueID().id));
					std::cout << (*playerIter)->getNameTag() << "自动睡觉失败，已移除床坐标数据" << std::endl;
				}
			}
		}
	}
	return rtn;
}


// ===== attack =====
THook(bool, "?attack@Player@@UEAA_NAEAVActor@@AEBW4ActorDamageCause@@@Z",
	Player* player, Actor* actor, int* damageCause)
{
	//sendPlayerText((Player*)player, "[Attack] -> " + getActorName(actor));
	auto master = getMasterOrNull(player);
	if (master != nullptr) {
		sendPlayerText((Player*)player, "代理" + getActorDescription(master) + "攻击" + getActorName(actor));
		return original(master, actor, damageCause);
	}
	return original(player, actor, damageCause);
}


// ===== Tcik Schedule =====
THook(void, "?tick@ServerLevel@@UEAAXXZ", void* _this) {
	if (funcSchedule.size() > 0) {
		// 效率可能不太高，但是在不大量设置长时间延迟的情况下应该没什么问题
		for (auto funcIter = funcSchedule.begin(); funcIter != funcSchedule.end(); ++funcIter) {
			if (funcIter->first < ticks) {
				funcIter->second();
				funcSchedule.erase(funcIter);
			}
		}
	}
	ticks++;
	original(_this);
}
// ===== Tcik Schedule =====
THook(void, "?move@Player@@UEAAXAEBVVec3@@@Z", Player* player, Vec3* v3) {
	auto master = getMasterOrNull(player);
	if (master != nullptr) {
		sendPlayerText((Player*)player, "代理" + getActorDescription(master) + "移动");
		Vec3 dst = (Vec3)(master->getPos()) + *v3;
		SymCall("?teleportTo@Player@@UEAAXAEBVVec3@@_NHH@Z", void, Player*, Vec3*)(master, &dst);
		original(master, v3);
	}
	return original(player, v3);
}
//THook(bool, "?isBaseCodeBuilderEnabled@EducationOptions@@SA_NXZ", void* _this) {
//	return true;
//}