#pragma once

enum struct Difficulty { Peaceful,
                         Easy,
                         Normal,
                         Hard };