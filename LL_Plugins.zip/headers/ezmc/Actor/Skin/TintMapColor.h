#pragma once

#include "../../Core/Color.h"

class TintMapColor {
    Color data[4];
};