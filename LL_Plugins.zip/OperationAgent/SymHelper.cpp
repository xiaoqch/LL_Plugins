#include "pch.h"
#include "SymHelper.h"

Minecraft* mc;

//namespace I18n {
//    std::string* get(std::string* ret, std::string* key) {
//        return SymCall("?get@I18n@@SA?AV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@AEBV23@@Z",
//            std::string*, std::string*, std::string*)(ret, key);
//    }
//    std::string get2(std::string key) {
//        std::string ret;
//        SymCall("?get@I18n@@SA?AV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@AEBV23@@Z",
//            std::string*, std::string*, std::string*)(&ret, &key);
//        return ret;
//    }
//}

THook(void, "?initAsDedicatedServer@Minecraft@@QEAAXXZ", void* self) {
  original(self);
  mc = (Minecraft*)self;
}

BlockSource* getBlockSourceByDim(int dimid) {
  auto dim = (int*)SymCall(
      "?getDimension@Level@@UEBAPEAVDimension@@V?$AutomaticID@VDimension@@H@@@"
      "Z",
      uintptr_t, void*, int)(mc->getLevel(), dimid);
  return dAccess<BlockSource*>(dim, 96);
}

void setOwner(Actor* actor, ActorUniqueID auid) {
  SymCall("?setOwner@Actor@@UEAAXUActorUniqueID@@@Z", void*, Actor*,
          ActorUniqueID)(actor, auid);
}
void setOwner(Actor* actor, long long auid) {
    setOwner(actor, ActorUniqueID(auid));
}


Player* getPlayerByAUID(ActorUniqueID auid) {
  return SymCall("?getPlayer@Level@@UEBAPEAVPlayer@@UActorUniqueID@@@Z",
                 Player*, Level*, ActorUniqueID)(mc->getLevel(), auid);
}
Player* getPlayerByAUID(long long auid) {
    return getPlayerByAUID(ActorUniqueID(auid));
}


Actor* getActorByAUID(ActorUniqueID auid) {
    return SymCall("?fetchEntity@Level@@UEBAPEAVActor@@UActorUniqueID@@_N@Z",
        Actor*, Level*, ActorUniqueID, bool)(mc->getLevel(), auid, true);
}
Actor* getActorByAUID(long long auid) {
    return getActorByAUID(ActorUniqueID(auid));
}

Mob* getMobByAUID(ActorUniqueID auid) {
    return SymCall("?getMob@Level@@UEBAPEAVMob@@UActorUniqueID@@@Z",
        Mob*, Level*, ActorUniqueID, bool)(mc->getLevel(), auid, true);
}
Mob* getMobByAUID(long long auid) {
    return getMobByAUID(ActorUniqueID(auid));
}

bool isPlayer(Actor* actor) {
    
    if (!actor)
        return false;
    auto vtbl = dlsym("??_7ServerPlayer@@6B@");
    return *(void**)actor == vtbl;
}

bool isSleeping(Player* player) {
    return *((bool*)player + 7648); //Player::isSleeping
}
bool isSleeping(Mob* mob) {//Mob::isSleeping
    return SymCall("?getStatusFlag@Actor@@QEBA_NW4ActorFlags@@@Z",
        bool, Actor*, int64_t)(mob, 75i64);
}

bool isEating(Mob* mob) {
    return SymCall("?isEating@Mob@@QEBA_NXZ", bool, Mob*)(mob);
}

void setEating(Mob* mob, bool b) {
    SymCall("?setEating@Mob@@QEAAX_N@Z", void, Mob*, bool)(mob, b);
}

void sendPlayerText(Player* player, std::string str) {
    WPlayer(*player).sendText(str, TextType::RAW);
}

//std::string* displayName, unsigned int entityTypeId, std::string* nameTag, Actor* actor
//std::string getActorName2(Actor* actor) {
//    if (actor == nullptr) {
//        return "";
//    }
//    string name = actor->getNameTag();
//    if (!name.empty()) {
//        return name;
//    }
//
//    string nameKey;
//    ActorType entityTypeId = actor->getEntityTypeId();
//    nameKey = SymCall("?buildActorDisplayName@@YA?AUKeyOrNameResult@@W4ActorType@@AEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@PEBVActor@@@Z",
//        string&, string*, ActorType, string*, Actor*)(&nameKey, entityTypeId, &name, actor);
//
//    string rtn;
//    return SymCall("?get@I18n@@SA?AV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@AEBV23@@Z",
//        string&, string*, string*)(&rtn, &nameKey);
//}

std::string getActorName(Actor* actor) {
    if (actor == nullptr) {
        return "";
    }
    string name;
    return SymCall("?getActorName@CommandUtils@@YA?AV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@AEBVActor@@@Z",
        std::string&, std::string*, Actor* actor)(&name, actor);
}


void setAgent(Player* master, Actor* agent) {
    SymCall("?setAgent@Player@@QEAAXPEAVAgent@@@Z",
        void, Player*, Actor*)(master, agent);
}

class Agent:Mob{
    void aiStep() {
        SymCall("?aiStep@Agent@@UEAAXXZ",
            void, Agent*)(this);
    }
    void kill() {
        SymCall("?kill@Agent@@UEAAXXZ",
            void, Agent*)(this);
    }
    void normalTick() {
        SymCall("?normalTick@Agent@@UEAAXXZ",
            void, Agent*)(this);
    }
    Vec3 roundTeleportPos(Vec3 pos) {
        return SymCall("?roundTeleportPos@Agent@@SA?AVVec3@@AEBV2@@Z",
            Vec3&, Agent* , Vec3&)(this, pos);
    }
    void setMoveTarget(Vec3 target) {
        SymCall("?setMoveTarget@Agent@@QEAAXAEBVVec3@@@Z",
            void, Agent*,  Vec3&)(this, target);
    }
    void setNameTagFromOwner(Player* player) {
        SymCall("?setNameTagFromOwner@Agent@@QEAAXAEBVPlayer@@@Z",
            void, Agent*, Player*)(this, player);
    }
    void startCommandMode() {
        SymCall("?startCommandMode@Agent@@QEAAXXZ",
            void, Agent*)(this);
    }
    void stopCommandMode() {
        SymCall("?stopCommandMode@Agent@@QEAAXXZ",
            void, Agent*)(this);
    }
    void swingAnimationCompleted() {
        SymCall("?swingAnimationCompleted@Agent@@QEAA_NXZ",
            void, Agent*)(this);
    }
    void swingArm() {
        SymCall("?swingArm@Agent@@QEAAXXZ",
            void, Agent*)(this);
    }
    Vec3 teleportTo(Vec3 pos, bool a2, int a3, int a4) {
        return SymCall("?teleportTo@Agent@@UEAAXAEBVVec3@@_NHH@Z",
            Vec3&, Agent*, Vec3&, bool, int, int)(this, pos, a2, a3, a4);
    }
    Vec3 travel(float a1, float a2, float a3) {
        return SymCall("?travel@Agent@@UEAAXMMM@Z",
            Vec3&, Agent*, float, float, float)(this, a1, a2, a3);
    }
};


Agent* getAgent(Player* master) {
    return SymCall("?getAgent@Player@@QEBAPEAVAgent@@XZ",
        Agent*, Player*)(master);
}
