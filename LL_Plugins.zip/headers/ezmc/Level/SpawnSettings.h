#pragma once

#include <string>

class SpawnSettings {
public:
    short       mUnknown = 0;
    std::string mValue   = "plains";
    int         dim;
};