#pragma once

enum class BlockFace : unsigned char {
    Down,
    Up,
    North,
    South,
    West,
    East,
};