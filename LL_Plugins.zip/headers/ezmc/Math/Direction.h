#pragma once

namespace Direction {
enum Type : char {};
}