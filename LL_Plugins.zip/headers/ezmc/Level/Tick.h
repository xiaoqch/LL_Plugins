#pragma once

#include <cstdint>

struct Tick {
    std::uint64_t value = {};
};