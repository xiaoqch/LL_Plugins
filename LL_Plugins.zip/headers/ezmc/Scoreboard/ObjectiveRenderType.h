#pragma once

enum class ObjectiveRenderType : char { list,
                                        sidebar,
                                        belowname };