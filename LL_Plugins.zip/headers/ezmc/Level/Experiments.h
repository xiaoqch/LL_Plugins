#pragma once

class Experiments {

public:
    char pad[40]; // todo
};