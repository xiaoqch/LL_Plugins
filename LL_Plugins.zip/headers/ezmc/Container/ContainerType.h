#pragma once

enum class ContainerType : char {};