#pragma once

#include "ActorUniqueID.h"

struct ActorLink {
    ActorUniqueID from, to;
};