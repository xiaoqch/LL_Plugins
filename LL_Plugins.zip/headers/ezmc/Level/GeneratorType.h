#pragma once

enum struct GeneratorType { Old,
                            Normal,
                            Flat };