#pragma once

inline namespace persona {
enum class AnimatedTextureType {
    animation_frames_32x32   = 2,
    animation_frames_128x128 = 3,
};
enum class PieceType {};

} // namespace persona