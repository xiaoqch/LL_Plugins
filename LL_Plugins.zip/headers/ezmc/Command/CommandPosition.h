#pragma once

#include "../Math/Vec3.h"

class CommandPosition {
public:
    Vec3 vec;
    bool mx, my, mz, op;
};