#pragma once

#define MCAPI __declspec(dllimport)