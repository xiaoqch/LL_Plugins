#include "../dll.h"

class ResolvedTextObject {};