#pragma once

enum class ObjectiveSortOrder : char { asc,
                                       desc };