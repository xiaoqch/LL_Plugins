#pragma once

enum class ContainerEnumName : char {};