#pragma once

enum struct GameType { Survival,
                       Creative,
                       Viewer    = 4,
                       Adventure = 5 };