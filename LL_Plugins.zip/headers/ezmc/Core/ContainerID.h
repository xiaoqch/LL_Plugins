#pragma once

enum class ContainerID : char {
    Invalid = -1,
    Inventory
};