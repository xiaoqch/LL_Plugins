
enum class DataType :int {
	None = 0,
	Sleep = 1,
	Ride = 2
};

bool setSleepData(long long auid, BlockPos bpos, optional<std::string> remark);
bool setRideData(long long riderUID, long long mountsUID, optional<std::string> remark);

bool deleteData(std::string skey);

DataType getDataType(long long auid);
BlockPos getSleepData(long long auid);
long long getRideData(long long auid);