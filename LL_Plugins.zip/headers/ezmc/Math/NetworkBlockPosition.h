#pragma once

#include "BlockPos.h"

class NetworkBlockPosition : public BlockPos {
};