#pragma once

#include "Player.h"

class ServerPlayer : public Player {
public:
    // place holder.. all implement in Player.h
};